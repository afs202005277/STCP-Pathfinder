var struct_node =
[
    [ "adj", "struct_node.html#a7aa02c84389aeb0d1adb961fddcbda46", null ],
    [ "dist", "struct_node.html#acb43bb8f558e3bac6fcc6801ce763402", null ],
    [ "edgePrev", "struct_node.html#a5287198e6490af15e15a12e8a1405466", null ],
    [ "pred", "struct_node.html#aeb26aebcf3533974d223c1cb6ca23c25", null ],
    [ "visited", "struct_node.html#aa1bdec4e775fc578632e6a2dced9e251", null ]
];