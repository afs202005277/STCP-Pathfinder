var class_stop =
[
    [ "Stop", "class_stop.html#a22a3420162c3ae3031f9261d051884c8", null ],
    [ "Stop", "class_stop.html#ab8870f949c69cda03c4055524ed13c31", null ],
    [ "getCode", "class_stop.html#aaad3d98bbd74f930bd5a925503a779ec", null ],
    [ "getLatitude", "class_stop.html#a9d10ee2761549c5d28f450d6841c8d09", null ],
    [ "getLongitude", "class_stop.html#adb957857f82251f8ae3faa69da9f5a8d", null ],
    [ "getZone", "class_stop.html#a6cf55c60966778bf8632de758040af53", null ]
];