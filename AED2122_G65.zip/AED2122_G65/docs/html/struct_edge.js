var struct_edge =
[
    [ "dest", "struct_edge.html#ad7df434ff7710e69f28bb31e91a35f82", null ],
    [ "distanceRealWorld", "struct_edge.html#a4eab2c6fe6f0158b74d8f24d98f64c6b", null ],
    [ "line", "struct_edge.html#ae38b631f93b9ab68914a9432625b4797", null ],
    [ "onFoot", "struct_edge.html#aa6bfb7992ff0b4de0ab0f000bc5e1c8a", null ],
    [ "zoneChanges", "struct_edge.html#a83254c8d5027b052d3154a0876f5527b", null ]
];