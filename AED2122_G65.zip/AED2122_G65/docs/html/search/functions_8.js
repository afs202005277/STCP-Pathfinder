var searchData=
[
  ['prim_0',['prim',['../class_graph.html#a8ca33342a436a05fc4f3a927febf5117',1,'Graph']]]
];
