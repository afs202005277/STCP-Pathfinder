var searchData=
[
  ['visited_0',['visited',['../struct_node.html#aa1bdec4e775fc578632e6a2dced9e251',1,'Node']]]
];
