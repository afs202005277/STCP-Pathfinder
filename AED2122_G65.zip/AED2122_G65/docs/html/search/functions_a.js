var searchData=
[
  ['stop_0',['Stop',['../class_stop.html#a22a3420162c3ae3031f9261d051884c8',1,'Stop::Stop(const string &amp;code, const string &amp;name, const string &amp;zone, double latitude, double longitude)'],['../class_stop.html#ab8870f949c69cda03c4055524ed13c31',1,'Stop::Stop()']]]
];
