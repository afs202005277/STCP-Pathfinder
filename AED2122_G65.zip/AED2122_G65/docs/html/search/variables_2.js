var searchData=
[
  ['edgeprev_0',['edgePrev',['../struct_node.html#a5287198e6490af15e15a12e8a1405466',1,'Node']]]
];
