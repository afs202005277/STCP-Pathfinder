var searchData=
[
  ['pred_0',['pred',['../struct_node.html#aeb26aebcf3533974d223c1cb6ca23c25',1,'Node']]]
];
