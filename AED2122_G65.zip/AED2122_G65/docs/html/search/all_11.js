var searchData=
[
  ['zonechanges_0',['zoneChanges',['../struct_edge.html#a83254c8d5027b052d3154a0876f5527b',1,'Edge']]]
];
