var searchData=
[
  ['adj_0',['adj',['../struct_node.html#a7aa02c84389aeb0d1adb961fddcbda46',1,'Node']]]
];
